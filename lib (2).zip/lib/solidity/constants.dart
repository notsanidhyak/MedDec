String url = "";

String contractAddressOfDeployed = "";

String privateKeyUser = "";

String publicKeyUser = "";