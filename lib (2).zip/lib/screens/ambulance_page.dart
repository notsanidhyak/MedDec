
import 'package:flutter/material.dart';

class AmbulancePage extends StatefulWidget {
  const AmbulancePage({Key? key}) : super(key: key);

  @override
  State<AmbulancePage> createState() => _AmbulancePageState();
}

class _AmbulancePageState extends State<AmbulancePage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(backgroundColor: Color(0xff151413),);
  }
}
