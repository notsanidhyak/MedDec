
import 'package:flutter/material.dart';

class Scans extends StatefulWidget {
  const Scans({Key? key}) : super(key: key);

  @override
  State<Scans> createState() => _ScansState();
}

class _ScansState extends State<Scans> {
  @override
  Widget build(BuildContext context) {
    return Container();
  }
}
